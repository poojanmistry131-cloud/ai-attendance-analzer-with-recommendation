# Attendance Ledger — Attendance Pattern Analyzer & Bunk-Risk Recommender

A mini project that analyzes a student's attendance CSV and recommends how
many classes can safely be missed (or must be attended) per subject, using a
mix of data analysis, a lightweight data-science trend model, interactive
visualization, and a rule/score-based recommendation engine.

## Concepts covered

| Concept                  | Where it lives                                            |
|---------------------------|------------------------------------------------------------|
| **Analysis**               | `backend/data_processor.py` — attendance %, streaks, day-of-week patterns |
| **Data Science**           | `backend/data_processor.py` (`numpy.polyfit` trend slope) and `backend/recommender.py` (4-week linear projection) |
| **Visualization**          | `frontend/script.js` — Chart.js trend/day charts, a hand-built SVG "bunk fuel gauge", and a register-style present/absent heatmap |
| **Recommendation Systems** | `backend/recommender.py` — hybrid rule-based (attendance-threshold math) + score-based ranking recommender |

## Project structure

```
attendance-analyzer/
├── backend/
│   ├── app.py                # FastAPI app: all API routes
│   ├── data_processor.py     # Analysis + data science (pandas, numpy)
│   ├── recommender.py        # Bunk-risk recommendation engine
│   ├── models.py             # Pydantic response/request schemas
│   ├── sample_data.csv       # Synthetic 16-week sample dataset (6 subjects)
│   └── requirements.txt
├── frontend/
│   ├── index.html            # Dashboard layout
│   ├── style.css             # Visual design (ledger/gradebook theme)
│   └── script.js             # API calls + gauge/chart/heatmap rendering
└── README.md
```

## How the pieces fit together

```
CSV upload / sample data
        │
        ▼
data_processor.py  ──►  per-subject stats, weekly trend slope, worst day
        │
        ▼
recommender.py     ──►  risk score, safe-bunk count, 4-week projection,
        │                plain-language recommendation
        ▼
app.py (FastAPI)   ──►  JSON over REST
        │
        ▼
frontend (HTML/CSS/JS) ──► gauge, charts, calendar heatmap, recommendation card
```

## Setup & running locally (VS Code)

You'll run two things side by side: the FastAPI backend (port 8000) and the
static frontend (any local server, e.g. port 5500). Two terminals in VS Code
(`` Ctrl+` `` / `` Cmd+` `` to open a terminal, then the `+` icon for a second one)
works well.

### 1. Backend (FastAPI)

```bash
cd attendance-analyzer/backend

# create and activate a virtual environment
python -m venv venv
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

pip install -r requirements.txt

uvicorn app:app --reload --port 8000
```

You should see `Uvicorn running on http://127.0.0.1:8000`. Visit
`http://127.0.0.1:8000/docs` for the interactive Swagger UI to try the API
directly.

### 2. Frontend (static HTML/CSS/JS)

The frontend is plain HTML/CSS/JS — no build step, no `npm install`. Two easy
ways to serve it:

**Option A — VS Code Live Server extension (recommended)**
1. Install the "Live Server" extension in VS Code.
2. Right-click `frontend/index.html` → "Open with Live Server".
3. It opens at something like `http://127.0.0.1:5500/frontend/index.html`.

**Option B — Python's built-in server**
```bash
cd attendance-analyzer/frontend
python -m http.server 5500
```
Then open `http://127.0.0.1:5500` in your browser.

> Keep the backend terminal running on port 8000 — the frontend's
> `API_BASE` in `script.js` points to `http://127.0.0.1:8000`. CORS is
> already enabled on the backend for local development.

### 3. Using it

1. Open the frontend in your browser.
2. Click **Load sample data** to explore the bundled 16-week synthetic
   dataset, or **Upload CSV** with your own file using the columns:
   ```csv
   Date,Subject,Status
   2026-01-05,Data Structures,Present
   2026-01-06,Data Structures,Absent
   ```
3. Pick a required-attendance threshold (65–85%) from the dropdown — every
   recommendation recalculates against it.
4. Click through subjects in the sidebar (sorted riskiest-first) to see the
   gauge, trend chart, day-of-week pattern, recommendation, and attendance
   calendar for each one.

## API reference (FastAPI backend)

| Method | Route                        | Purpose                                    |
|--------|-------------------------------|---------------------------------------------|
| GET    | `/api/health`                 | Liveness check                             |
| GET    | `/api/sample`                 | Load the bundled sample dataset            |
| POST   | `/api/upload`                 | Upload a CSV (`multipart/form-data`, field `file`) |
| GET    | `/api/analysis`               | Per-subject stats + overall summary        |
| GET    | `/api/recommendations?threshold=0.75` | Bunk-risk recommendations per subject |
| GET    | `/api/calendar/{subject}`     | Daily present/absent log for one subject   |

## Extending this project

- Swap the in-memory `STATE` dict in `app.py` for SQLite/PostgreSQL to
  persist multiple students' registers.
- Add authentication so each student only sees their own data.
- Replace the linear-regression projection in `recommender.py` with a proper
  `scikit-learn` model (e.g. `LogisticRegression` predicting probability of
  dropping below threshold) for a deeper data-science angle.
- Add a "what-if" slider on the frontend that recomputes `safe_bunks` live as
  the student drags a hypothetical future-attendance slider.
